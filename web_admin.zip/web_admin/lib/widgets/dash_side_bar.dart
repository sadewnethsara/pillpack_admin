import 'package:flutter/material.dart';
import 'package:flutter_vector_icons/flutter_vector_icons.dart';
import 'package:web_admin/Dashboard/src/DashMainButton.dart';
import 'package:web_admin/config/palette.dart';
import 'custom_dialog.dart';
import 'tags.dart';

import 'package:flutter/foundation.dart' show kIsWeb;

class DashSideBar extends StatelessWidget {
  const DashSideBar({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.infinity,
      padding: EdgeInsets.only(top: kIsWeb ? kDefaultPadding : 0),
      color: kBgLightColor,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              Row(
                children: [],
              ),
              SizedBox(height: kDefaultPadding),
              GestureDetector(
                onTap: () {},
                child: DashMainButton(
                  color: Color(0xFF366CF6),
                  projectName: 'Create New',
                  icon: Feather.folder_plus,
                ),
              ),
              SizedBox(height: kDefaultPadding),
              GestureDetector(
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return Container(
                        margin: EdgeInsets.symmetric(
                            horizontal: MediaQuery.of(context).size.width / 5,
                            vertical: MediaQuery.of(context).size.height / 12),
                        decoration: new BoxDecoration(
                          shape: BoxShape.rectangle,
                          color: Colors.white,
                          borderRadius:
                              new BorderRadius.all(new Radius.circular(32.0)),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.8),
                              spreadRadius: 3,
                              blurRadius: 5,
                              offset:
                                  Offset(4, 4), // changes position of shadow
                            ),
                          ],
                        ),
                        child: CustomDialogBox(),
                      );
                    },
                  );
                },
                child: DashMainButton(
                  color: Color(0xFF366CF6),
                  projectName: 'The Maptrix',
                  icon: Feather.moon,
                ),
              ),

              SizedBox(height: kDefaultPadding * 2),
              // Tags
              Tags(),
            ],
          ),
        ),
      ),
    );
  }
}
