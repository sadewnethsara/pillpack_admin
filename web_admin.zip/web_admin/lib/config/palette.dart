import 'package:flutter/material.dart';

class Palette {
  static const Color scaffold = Color(0xFFF0F2F5);

  static const Color facebookBlue = Color(0xFF1777F2);

  static const LinearGradient createRoomGradient = LinearGradient(
    colors: [Color(0xFF496AE1), Color(0xFFCE48B1)],
  );

  static const Color online = Color(0xFF4BCB1F);

  static const LinearGradient storyGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Colors.transparent, Colors.black26],
  );
}

// All of our constant stuff

const kPrimaryColor = Color(0xFF366CF6);
const kSecondaryColor = Color(0xFFF5F6FC);
const kBgLightColor = Color(0xFFF2F4FC);
const kBgDarkColor = Color(0xFFEBEDFA);
const kBadgeColor = Color(0xFFEE376E);
const kGrayColor = Color(0xFF8793B2);
const kTitleTextColor = Color(0xFF30384D);
const kTextColor = Color(0xFF4D5875);

const kDefaultPadding = 20.0;
const Color color1 = Color(0xffFFA000);
const Color color2 = Color(0xff8CE3F3);
const Color color3 = Color(0xffF25767);
const Color color4 = Color(0xff6B6EDF);
const Color backgroundColor = Color(0xffFFFFFF);
const Color mainTextColor = Color(0xff332A7C);
const Color monthButtonColor = Color(0xffF8F8FD);
const Color rightSideBackColor = Color(0xffF6F6FC);
const Color disableColor = Color(0xffE7E7F7);
