import 'package:flutter/material.dart';
import 'package:flutter_vector_icons/flutter_vector_icons.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:web_admin/Dashboard/src/ProjectProgressCard.dart';
import 'package:web_admin/config/palette.dart';

class DashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width * 0.5,
        padding: EdgeInsets.symmetric(horizontal: 20.0),
        color: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.only(top: 25.0),
                height: 120.0,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                      stops: [
                        0.4,
                        0.8,
                      ],
                      colors: [
                        Color(0xffFF4C60).withOpacity(1.0),
                        Color(0xffFF4C60).withOpacity(1.0),
                      ]),
                  borderRadius: BorderRadius.circular(20.0),
                ),
                alignment: Alignment.centerRight,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    FittedBox(
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [],
                          ),
                          SizedBox(height: 5),
                          Padding(
                            padding: const EdgeInsets.only(left: 20.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Hello, Sadew Nthsara',
                                  style: GoogleFonts.raleway(
                                      fontSize: 20.0,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white),
                                ),
                                Text(
                                  'Welcome to Admin Panel',
                                  style: GoogleFonts.quicksand(
                                      fontSize: 15.0, color: Colors.white),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 25.0,
              ),
              Container(
                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                height: 1.0,
                color: Colors.black12,
              ),
              Container(
                margin: EdgeInsets.only(top: 15.0),
                width: MediaQuery.of(context).size.width * 0.62,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    ProjectProgressCard(
                      color: Color(0xffFF4C60),
                      projectName: 'The Maptrix',
                      percentComplete: '34%',
                      progressIndicatorColor: Colors.redAccent[100],
                      icon: Feather.moon,
                    ),
                    SizedBox(
                      height: 25.0,
                    ),
                    ProjectProgressCard(
                      color: Color(0xff6C6CE5),
                      projectName: 'Delivery Club',
                      percentComplete: '78%',
                      progressIndicatorColor: Colors.blue[200],
                      icon: Feather.truck,
                    ),
                    SizedBox(
                      height: 25.0,
                    ),
                    ProjectProgressCard(
                      color: Color(0xffFAAA1E),
                      projectName: 'Travel Comrode',
                      percentComplete: '82%',
                      progressIndicatorColor: Colors.amber[200],
                      icon: Icons.local_airport,
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                height: 1.0,
                color: Colors.black12,
              ),
              SizedBox(
                height: 10.0,
              ),
              SizedBox(
                height: 15.0,
              ),
              SizedBox(
                height: 10.0,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CalendarPellet extends StatefulWidget {
  final String text;
  final String subText;
  final Color color;
  CalendarPellet({
    this.color,
    this.subText,
    this.text,
  });
  @override
  _CalendarPelletState createState() => _CalendarPelletState();
}

class _CalendarPelletState extends State<CalendarPellet> {
  bool exit = true;
  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (value) {
        setState(() {
          exit = false;
        });
      },
      onExit: (v) {
        setState(() {
          exit = true;
        });
      },
      child: AnimatedContainer(
        height: exit ? 60.0 : 75.0,
        width: exit ? 40.0 : 45.0,
        duration: Duration(milliseconds: 200),
        decoration: BoxDecoration(
            color: exit ? Colors.white : color3,
            borderRadius: BorderRadius.circular(10.0),
            boxShadow: exit
                ? []
                : [
                    BoxShadow(
                      color: color3,
                      blurRadius: 10.0,
                    ),
                  ]),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              widget.text,
              style: GoogleFonts.nunitoSans(
                  fontSize: 13.0,
                  fontWeight: FontWeight.bold,
                  color: exit ? Color(0xff45417C) : Colors.white),
            ),
            SizedBox(
              height: 5.0,
            ),
            Text(
              widget.subText,
              style: GoogleFonts.nunitoSans(
                color: exit ? Colors.black87 : Colors.white,
                fontSize: 14.0,
                fontWeight: FontWeight.normal,
              ),
            ),
            SizedBox(
              height: 3.0,
            ),
            Container(
              height: 4.0,
              width: 4.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: exit ? widget.color : Colors.white,
              ),
            )
          ],
        ),
      ),
    );
  }
}

class WeeklyReportCards extends StatefulWidget {
  final String text;
  final Color color;
  final String buttonText;
  final IconData icon;
  WeeklyReportCards({
    this.buttonText,
    this.color,
    this.text,
    this.icon,
  });
  @override
  _WeeklyReportCardsState createState() => _WeeklyReportCardsState();
}

class _WeeklyReportCardsState extends State<WeeklyReportCards> {
  bool exit = true;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (value) {
        setState(() {
          exit = false;
        });
      },
      onExit: (value) {
        setState(() {
          exit = true;
        });
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        height: exit ? 120.0 : 140.0,
        width: 100.0,
        decoration: BoxDecoration(
          color: exit ? Colors.white : Colors.white,
          borderRadius: BorderRadius.circular(20.0),
          border: Border.all(
            color: exit ? Colors.black12 : Colors.transparent,
          ),
          boxShadow: exit
              ? []
              : [
                  BoxShadow(
                    spreadRadius: 1.0,
                    blurRadius: 20.0,
                    color: Colors.grey[200],
                  ),
                ],
        ),
        child: Column(
          children: [
            AnimatedContainer(
              duration: Duration(milliseconds: 200),
              margin: EdgeInsets.only(top: 15.0),
              padding: EdgeInsets.all(8.0),
              decoration: BoxDecoration(
                  border: Border.all(
                    color: !exit ? Colors.transparent : widget.color,
                  ),
                  color: !exit ? widget.color : Colors.white,
                  borderRadius: BorderRadius.circular(10.0)),
              child: Icon(
                widget.icon,
                size: 16.0,
                color: !exit ? Colors.white : widget.color,
              ),
            ),
            Spacer(),
            Text(
              widget.text,
              style: GoogleFonts.nunitoSans(
                fontSize: 13.0,
                color: mainTextColor,
              ),
            ),
            Spacer(),
            SizedBox(
              height: 5.0,
            ),
          ],
        ),
      ),
    );
  }
}
