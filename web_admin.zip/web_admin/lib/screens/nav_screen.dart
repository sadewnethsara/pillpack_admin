import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_vector_icons/flutter_vector_icons.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:web_admin/Admin/admin_tab.dart';
import 'package:web_admin/Dashboard/dasboard_tab.dart';
import 'package:web_admin/Details/details_tab.dart';
import 'package:web_admin/Doctor/doctor_tab.dart';
import 'package:web_admin/Patient/patient_tab.dart';
import 'package:web_admin/Settings/settings_tab.dart';
import 'package:web_admin/forms/add_new_form.dart';
import 'package:web_admin/widgets/widgets.dart';

import 'home_screen.dart';

class NavScreen extends StatefulWidget {
  @override
  _NavScreenState createState() => _NavScreenState();
}

class _NavScreenState extends State<NavScreen> {
  final List<Widget> _screens = [
    DashboardTab(),
    DetailsTab(),
    AdminTab(),
    DoctorTab(),
    PatientTab(),
    SettingsTab(),
  ];
  final List<IconData> _icons = const [
    Icons.dashboard,
    Icons.apps,
    Icons.admin_panel_settings,
    FontAwesome.user_md,
    Feather.user_plus,
    Feather.settings,
  ];
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;
    return DefaultTabController(
      length: _icons.length,
      child: Scaffold(
        appBar: Responsive.isDesktop(context)
            ? PreferredSize(
                preferredSize: Size(screenSize.width, 100.0),
                child: CustomAppBar(
                  icons: _icons,
                  selectedIndex: _selectedIndex,
                  onTap: (index) => setState(() => _selectedIndex = index),
                ),
              )
            : null,
        body: IndexedStack(
          index: _selectedIndex,
          children: _screens,
        ),
        bottomNavigationBar: !Responsive.isDesktop(context)
            ? Container(
                padding: const EdgeInsets.only(bottom: 12.0),
                color: Colors.white,
                child: CustomTabBar(
                  icons: _icons,
                  selectedIndex: _selectedIndex,
                  onTap: (index) => setState(() => _selectedIndex = index),
                ),
              )
            : const SizedBox.shrink(),
      ),
    );
  }
}
