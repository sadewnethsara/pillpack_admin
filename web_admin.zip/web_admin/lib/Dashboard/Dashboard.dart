import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../Dashboard/src/ProjectStatisticsCards.dart';
import '../Dashboard/src/SharedFilesItem.dart';
import '../Dashboard/src/SubHeader.dart';

class DashBoard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width * 0.63,
        color: Colors.white,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin: EdgeInsets.only(left: 30.0, top: 25.0, bottom: 10.0),
              child: Text(
                'Dashboard',
                style: GoogleFonts.quicksand(
                  fontWeight: FontWeight.bold,
                  fontSize: 30.0,
                ),
              ),
            ),
            ProjectStatisticsCards(),
            SizedBox(height: 25),
            ProjectStatisticsCards(),
            SizedBox(height: 25),
            SubHeader(
              title: 'Shared Files',
            ),
            SharedFilesItem(
              color: Colors.blue,
              sharedFileName: 'Company Guidelines',
              members: '28 members',
              et: '10 Oct 2019',
              fileSize: '2.3 MB',
            ),
            SharedFilesItem(
              color: Colors.amber,
              sharedFileName: 'Company Policy',
              members: '30 members',
              et: '27 Sep 2019',
              fileSize: '4.2 MB',
            ),
            SharedFilesItem(
              color: Colors.red,
              sharedFileName: 'Wireframes',
              members: '14 members',
              et: '08 Oct 2019',
              fileSize: '1.6 MB',
            ),
            SubHeader(
              title: 'Project Statistics',
            ),
          ],
        ),
      ),
    );
  }
}
